import os
import zipfile

items_to_zip = ["models", "strategies", "requirements.txt"] + [f for f in os.listdir() if f.endswith(".py")]

with zipfile.ZipFile("kaggle_upload.zip", "w", zipfile.ZIP_DEFLATED) as zf:
    for item in items_to_zip:
        if os.path.isfile(item):
            zf.write(item, arcname=item.replace("\\", "/"))
        elif os.path.isdir(item):
            for root, _, files in os.walk(item):
                if "__pycache__" in root: continue
                for file in files:
                    full_path = os.path.join(root, file)
                    zf.write(full_path, arcname=full_path.replace("\\", "/"))
